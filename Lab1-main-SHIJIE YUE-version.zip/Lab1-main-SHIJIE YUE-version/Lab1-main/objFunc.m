function [y]=objFunc(x)
y = x.^2;
end